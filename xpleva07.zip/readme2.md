# BUT_FIT_IPP_2
Project 2 to IPP
